# Braja Mustika Decoration — 3D Stage Viewer

Interactive 3D stage and layout viewer for **Braja Mustika Convention Centre, Bogor** (20/10/26).

## Project Structure

```text
braja-mustika-decoration/
├── index.html        # Page markup and Three.js import map
├── css/
│   └── styles.css    # Theme, layout, and responsive control panel styles
├── js/
│   └── app.js        # Three.js scene, lighting, camera presets, and UI logic
├── assets/
│   └── stage.glb     # 3D convention hall & stage model (glTF binary)
└── README.md
```

## Running Locally

Because the viewer loads `assets/stage.glb` via `fetch` and uses ES modules, serve the folder over HTTP rather than opening `index.html` via `file://`:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000` in your browser.

## Deploying to GitHub Pages

1. Upload all files in this folder to a new GitHub repository.
2. Go to **Settings → Pages**, select the main branch (`/(root)`), and save.
