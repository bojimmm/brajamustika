import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const $ = (s) => document.querySelector(s);
const P = (x, y, z) => new THREE.Vector3(x, z, -y);      // model (Z-up, metres) -> three.js (Y-up)

// ---------------------------------------------------------------- renderer / scene
const host = $('#stage');
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
const mobile = matchMedia('(max-width: 760px)').matches || /Mobi|Android/i.test(navigator.userAgent);
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.5 : 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.outputColorSpace = THREE.SRGBColorSpace;
host.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x120f12);
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
const hemi = new THREE.HemisphereLight(0xfff4e0, 0x3a2a20, 0.35);
scene.add(hemi);

const camera = new THREE.PerspectiveCamera(58, 1, 0.05, 400);
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; controls.dampingFactor = 0.08;
controls.maxPolarAngle = Math.PI * 0.495; controls.minDistance = 0.6; controls.maxDistance = 90;
controls.screenSpacePanning = true;

function resize() {
  const w = host.clientWidth, h = host.clientHeight;
  renderer.setSize(w, h, false); camera.aspect = w / h;
  // on wide screens, centre the scene in the area left of the floating panel
  const panel = document.getElementById('panel');
  const shift = (w > 760 && panel) ? (panel.offsetWidth + 16) / 2 : 0;
  if (shift) camera.setViewOffset(w, h, shift, 0, w, h); else camera.clearViewOffset();
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize); resize();

// ---------------------------------------------------------------- lights
const hallLights = new THREE.Group(), styleLights = { 1: new THREE.Group(), 2: new THREE.Group(), 3: new THREE.Group() };
scene.add(hallLights, styleLights[1], styleLights[2], styleLights[3]);
for (const y of [-17.4, -10.9, -4.3, 2.2, 8.7, 15.2]) for (const x of [-6.3, 0, 6.3]) {
  const l = new THREE.PointLight(0xffe2b8, x === 0 ? 60 : 25, 22, 1.6); l.position.copy(P(x, y, 7.0)); l.userData.base = l.intensity; hallLights.add(l);
}
function spotOnStage(group, color, power) {
  const s = new THREE.SpotLight(color, power, 26, 0.75, 0.6, 1.2);
  s.position.copy(P(0, 17.0, 5.6)); s.target.position.copy(P(0, 22.4, 1.6)); s.userData.base = power;
  group.add(s, s.target);
}
spotOnStage(styleLights[1], 0xfff0dd, 90);
spotOnStage(styleLights[2], 0xffe6cc, 80);
for (const [x, z] of [[-2.6, 3.4], [0, 3.45], [2.6, 3.4]]) {
  const l = new THREE.PointLight(0xffd8a0, 9, 7, 1.6); l.position.copy(P(x, 22.75, z)); l.userData.base = 9; styleLights[2].add(l);
}
spotOnStage(styleLights[3], 0xffd9b0, 55);
for (const [x, y, z] of [[-5.2, 22, 3.9], [-3.5, 21.4, 4.1], [-1.8, 22, 4.3], [0, 21.4, 4.3], [1.8, 22, 4.3], [3.5, 21.4, 4.1], [5.2, 22, 3.9], [0, 19.8, 4.8], [0, 18.6, 1.2]]) {
  const l = new THREE.PointLight(0xffb86b, 6, 8, 1.7); l.position.copy(P(x, y, z)); l.userData.base = 6; styleLights[3].add(l);
}

// ---------------------------------------------------------------- content
const STYLES = {
  1: { name: 'Plain', light: 'bright',
       text: 'A clean base to build on: three ivory arch panels with gold frames, light blush and white florals, a cream loveseat with four parents’ chairs, standing flower stands at the stage edge and a low mini garden in front.',
       items: ['Arch backdrop ~4 m wide, side panels angled', 'Skirted akad table centred in front of the stage, 4 Tiffany chairs', 'Easiest to restyle with your own colours'] },
  2: { name: 'Royal Gebyok', light: 'bright',
       text: 'From your first reference: a carved dark-wood gebyok crown with gold relief and peacock motifs over burgundy velvet drapes with swags, on an ivory pleated backdrop.',
       items: ['Three candle-shade crystal chandeliers', 'Red, pink and white rose hedge with orchid sprays', 'Louis sofa with burgundy cushions, 4 medallion chairs', 'Mirror-and-gold akad table, burgundy velvet chairs, melati strands'] },
  3: { name: 'Javanese Garden', light: 'evening',
       text: 'From your second reference: a dark carved teak gebyok wall softened by palms, monstera and banana leaves, with a round blush-and-peach floral piece at the centre.',
       items: ['Janur / kembar mayang ornaments on both sides', 'Overhead white flower garlands, sheer swags, fairy lights', 'Candle chandeliers and pillar candles; best in Evening light', 'Lace-draped akad table with dark cross-back chairs'] },
};
const CEILING = ['Roof_and_Slabs', 'Ceiling', 'Ceiling_Ancillary', 'Lighting_Chandeliers', 'Lighting_Downlights', 'HVAC', 'Fire_Safety', 'Lighting_Cove'];
const AKAD = ['Akad_Set_Plain', 'Akad_Table_Mirror', 'Akad_Table_Lace'];
const VIEWS = {
  entrance: { pos: P(0, -22.6, 1.7), tgt: P(0, 0, 2.4) },
  stage:    { pos: P(0, 10.8, 1.7),  tgt: P(0, 22.6, 2.5) },
  akad:     { pos: P(0, 12.4, 1.5),  tgt: P(0, 17.8, 1.0) },
  side:     { pos: P(9.0, 12.0, 2.2), tgt: P(0, 21.5, 2.0) },
  aerial:   { pos: P(-27, -27, 30),  tgt: P(0, 0, 0), cutaway: true },
};

let model = null;
const state = { style: 1, light: 'bright', lightTouched: false, ceiling: true, layout: true, akad: true, view: 'stage' };
const nodes = {};
const byName = (n) => nodes[n] || (nodes[n] = model && model.getObjectByName(n));

function apply() {
  if (!model) return;
  for (const s of [1, 2, 3]) {
    const n = byName(['', 'STAGE_1_Plain', 'STAGE_2_Royal_Gebyok', 'STAGE_3_Javanese_Garden'][s]);
    if (n) n.visible = state.style === s;
    styleLights[s].visible = state.style === s;
  }
  for (const n of CEILING) { const o = byName(n); if (o) o.visible = state.ceiling; }
  const lay = byName('LAYOUT_Wedding_Sample'); if (lay) lay.visible = state.layout;
  for (const n of AKAD) { const o = byName(n); if (o) o.visible = state.akad; }
  const ev = state.light === 'evening';
  scene.environmentIntensity = ev ? 0.05 : 0.55;
  hemi.intensity = ev ? 0.05 : 0.35;
  renderer.toneMappingExposure = ev ? 1.15 : 1.0;
  hallLights.children.forEach(l => l.intensity = l.userData.base * (ev ? 0.06 : 1));
  for (const s of [1, 2, 3]) styleLights[s].children.forEach(l => { if (l.isLight) l.intensity = l.userData.base * (ev ? 1.6 : 1); });
  scene.background.set(ev ? 0x07060a : 0x120f12);
  // UI state
  document.querySelectorAll('[data-style]').forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.style === state.style)));
  document.querySelectorAll('[data-light]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.light === state.light)));
  document.querySelectorAll('[data-toggle]').forEach(b => b.setAttribute('aria-pressed', String(state[b.dataset.toggle])));
  document.querySelectorAll('[data-view]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.view === state.view)));
  const st = STYLES[state.style];
  $('#styleDesc').innerHTML = `${st.text}<ul>${st.items.map(i => `<li>${i}</li>`).join('')}</ul>`;
  try { localStorage.setItem('bm-stage-state', JSON.stringify({ style: state.style, light: state.light, lightTouched: state.lightTouched })); } catch (e) {}
}

// camera tween
let tween = null;
function goTo(name, instant) {
  const v = VIEWS[name]; state.view = name;
  if (v.cutaway && state.ceiling) state.ceiling = false;
  apply();
  const pos = v.pos.clone();
  if (camera.aspect < 1 && !v.cutaway) pos.sub(v.tgt).multiplyScalar(1 + (1 - camera.aspect) * 1.4).add(v.tgt);   // portrait phones: step back
  if (instant) { camera.position.copy(pos); controls.target.copy(v.tgt); controls.update(); return; }
  tween = { t: 0, p0: camera.position.clone(), t0: controls.target.clone(), p1: pos, t1: v.tgt.clone() };
}

// UI events
document.querySelectorAll('[data-style]').forEach(b => b.addEventListener('click', () => {
  state.style = +b.dataset.style;
  if (!state.lightTouched) state.light = STYLES[state.style].light;
  apply();
}));
document.querySelectorAll('[data-light]').forEach(b => b.addEventListener('click', () => { state.light = b.dataset.light; state.lightTouched = true; apply(); }));
document.querySelectorAll('[data-toggle]').forEach(b => b.addEventListener('click', () => { const k = b.dataset.toggle; state[k] = !state[k]; apply(); }));
document.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', () => goTo(b.dataset.view)));
$('#sheetToggle').addEventListener('click', () => {
  const p = $('#panel'); const c = p.classList.toggle('collapsed');
  $('#sheetToggle').textContent = c ? 'More options ▴' : 'Hide options ▾';
  $('#sheetToggle').setAttribute('aria-expanded', String(!c));
});
if (mobile) { $('#panel').classList.add('collapsed'); $('#sheetToggle').textContent = 'More options ▴'; $('#sheetToggle').setAttribute('aria-expanded', 'false'); }
controls.addEventListener('start', () => { tween = null; });

// restore per-viewer convenience state
try {
  const s = JSON.parse(localStorage.getItem('bm-stage-state') || 'null');
  if (s && [1, 2, 3].includes(s.style)) { state.style = s.style; state.light = s.light === 'evening' ? 'evening' : 'bright'; state.lightTouched = !!s.lightTouched; }
} catch (e) {}
if (location.hash === '#style-2') state.style = 2;
if (location.hash === '#style-3') state.style = 3;
if (location.hash === '#style-1') state.style = 1;

// ---------------------------------------------------------------- load embedded, gzip-compressed GLB
async function loadModel() {
  $('#loadMsg').textContent = 'Loading 3D model';
  const gltf = await new GLTFLoader().loadAsync('assets/stage.glb', (xhr) => {
    if (xhr.lengthComputable) {
      const pct = Math.round((xhr.loaded / xhr.total) * 100);
      $('#loadMsg').textContent = `Loading 3D model (${pct}%)`;
    }
  });
  $('#loadMsg').textContent = 'Building scene';
  model = gltf.scene;
  model.traverse(o => { if (o.isMesh) { o.frustumCulled = true; if (o.material && o.material.transparent) o.material.depthWrite = false; } });
  scene.add(model);
}

const loader = $('#loader');
loadModel().then(() => {
  goTo('stage', true);
  loader.style.opacity = '0'; setTimeout(() => loader.hidden = true, 600);
}).catch(err => {
  $('#loadMsg').textContent = 'The 3D model could not load: ' + err.message + '. Try a current Chrome, Safari or Firefox.';
  console.error(err);
});

// ---------------------------------------------------------------- loop
const clock = new THREE.Clock();
renderer.setAnimationLoop(() => {
  const dt = Math.min(clock.getDelta(), 0.05);
  if (tween) {
    tween.t = Math.min(1, tween.t + dt / 1.1);
    const e = tween.t < .5 ? 4 * tween.t ** 3 : 1 - (-2 * tween.t + 2) ** 3 / 2;
    camera.position.lerpVectors(tween.p0, tween.p1, e); controls.target.lerpVectors(tween.t0, tween.t1, e);
    if (tween.t >= 1) tween = null;
  }
  controls.update();
  renderer.render(scene, camera);
});
window.__bm = { state, apply, goTo, ready: () => !!model, pause: () => renderer.setAnimationLoop(null), renderNow: () => { controls.update(); renderer.render(scene, camera); } };
